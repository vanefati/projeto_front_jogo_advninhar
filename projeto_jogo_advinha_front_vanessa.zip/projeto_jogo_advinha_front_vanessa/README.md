# projeto_jogo_advinha_front_vanessa

A Pen created on CodePen.io. Original URL: [https://codepen.io/vanefati/pen/RwvZmjR](https://codepen.io/vanefati/pen/RwvZmjR).

O objetivo do jogo é tentar advinhar o número entre 1 até 1000.

O jogador terá a chance de testar até 5 cinco vezes.

Façam bom proveito do jogo e boa sorte!