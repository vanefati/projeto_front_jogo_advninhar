
alert (' Seja bem vindo ao jogo de advinhar! ');

var nomeJogador = prompt(' Como você se chama? ');

alert (' Olá '  + nomeJogador + ' Você terá até 5 chances para acertar \n\n ' + ' Força você consegue! ');

alert (' Boa sorte! ');

var numeroSecreto = parseInt(Math.random() * 1000)+1;
var valorContador = 0;
var valoLimiteTentativas =  5;

while(tentativa != numeroSecreto) {
  
var tentativa= prompt(' Digite um número entre 1 até 1000 ');
  
 valorContador++;
  
  if (valorContador >= valoLimiteTentativas){
    alert (' Lamento ' + nomeJogador + ' seu número de tentativas esgotou! ');
    alert (' Até a próxima! ');
    
    break;
  }
  
  if (tentativa == numeroSecreto) {
        alert (' Acertou!')
    
     } else if (tentativa > numeroSecreto) {
        alert(' Errou...o número secreto é menor')
    } else if (tentativa < numeroSecreto) {
        alert(' Errou...o número secreto é maior ')
    }
}



//enquanto o chute for diferente do numero secreto
// se o chute for igual ao número secreto